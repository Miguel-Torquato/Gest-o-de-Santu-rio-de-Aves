import { Pressable, Image, Button, TextInput, StyleSheet, Text, View } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>

      <Image
        source={{
          uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTGZNK18c5Os4rLwT3t4y-i_lOMVgtBAkMq2giXfiH0JA&s=10"
        }}
        style={styles.image}
      />

      <Text style={styles.label}>Insira seu email:</Text>

      <TextInput
        placeholder='joaozinho123@gmail.com'
        style={styles.input}
      />

      <Text style={styles.label}>Insira sua senha:</Text>

      <TextInput
        placeholder='Digite sua senha'
        style={styles.input}
        secureTextEntry={true}
      />

      <Button
        title='Entrar'
        onPress={() => alert("Dados enviados")}
        disabled={false}
      />

      <Pressable onPress={() => alert("Recuperar senha")}>
        <Text style={styles.link}>Esqueci a senha</Text>
      </Pressable>

      <Pressable onPress={() => alert("Criar conta")}>
        <Text style={styles.link}>Criar conta</Text>
      </Pressable>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 20,
  },

  image: {
    width: 120,
    height: 120,
    borderRadius: 10,
    marginBottom: 25,
  },

  label: {
    fontSize: 16,
    marginBottom: 8,
  },

  input: {
    width: '100%',
    height: 45,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 15,
  },

  link: {
    marginTop: 15,
    fontSize: 15,
    textDecorationLine: 'underline',
  },
});