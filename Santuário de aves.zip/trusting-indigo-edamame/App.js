import React from 'react';
import { View, Text, Image, StyleSheet }
from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>

    <Image
     source={{
       uri:
       'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR72gwmWKwjxGZ30FVyvW56smoNI4QH0pujLA&s.png'
     }}
     style={styles.logo}
     />

     <Text style={styles.titulo}>
     Santuário de Aves
     </Text>

     <Text style={styles.subtitulo}>
     Onde a natureza encontra seu refúgio
     </Text>

     <Text style={styles.rodape}>
     v1.0 - Miguel Lima
     </Text>

     </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#2F5D50',
    alignItems: 'center',
    justifyContent: 'center',
  },

  logo: {
    width: 120,
    height: 120,
    marginBottom: 25,
  },

  titulo: {
    fontSize: 32,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 10,
  },

  subtitulo: {
    fontSize: 16,
    color: '#Dbeafe',
    textAlign: 'center',
  },

  rodape: {
    position: 'absolute',
    bottom: 25,
    fontSize: 12,
    color: '#BFDBFE',
  },
});